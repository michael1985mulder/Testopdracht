using Microsoft.Playwright.NUnit;
using NUnit.Framework;
using FluentAssertions;
using ValoriApiTests.Helpers;
using ValoriApiTests.ApiClients;
using Newtonsoft.Json.Linq;
using Microsoft.Playwright;
using System.Threading.Tasks;

namespace ValoriApiTests.Tests
{
    [TestFixture]
    public class OpenWeatherTests : PageTest
    {
        private IAPIRequestContext _api = null!;
        private OpenWeatherClient _client = null!;
        private string _appId = null!;
        private string _baseUrl = null!;

        [OneTimeSetUp]
        public async Task OneTimeSetup()
        {
            var config = ApiHelper.LoadConfiguration();
            _appId = config["OpenWeather:AppId"] ?? "";
            _baseUrl = config["OpenWeather:BaseUrl"] ?? "https://api.openweathermap.org/data/2.5/";

            _api = await ApiHelper.CreateApiContextAsync(_baseUrl);
            _client = new OpenWeatherClient(_api, "");
        }

        [OneTimeTearDown]
        public async Task OneTimeTeardown()
        {
            if (_api != null)
            {
                await _api.DisposeAsync();
            }
        }

        [Test, Category("Opdracht1")]
        public async Task NoAppId_ShouldReturn401()
        {
            var response = await _client.GetWeatherByCityAsync("Utrecht");
            response.Status.Should().Be(401);

            var body = await response.TextAsync();
            body.Should().Contain("Invalid");
        }

        [Test, Category("Opdracht2")]
        public async Task ValidRequest_ShouldReturnWeatherForUtrecht()
        {
            var response = await _client.GetWeatherByCityAsync("Utrecht", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            json["name"]!.ToString().Should().Be("Provincie Utrecht");
        }

        [TestCase("Amsterdam", 2759794)]
        [TestCase("Rotterdam", 2747891)]
        [TestCase("Den Haag", 2747373)]
        [TestCase("Groningen", 2755249)]
        [Category("Opdracht4")]
        public async Task CityId_ShouldMatchExpected(string city, int expectedId)
        {
            var response = await _client.GetWeatherByCityAsync(city, _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            ((int)json["id"]!).Should().Be(expectedId);
        }

        [Test, Category("Opdracht3")]
        public async Task CreativeTest_CheckTemperatureIsReturned()
        {
            var response = await _client.GetWeatherByCityAsync("Amsterdam", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            json["main"]?["temp"].Should().NotBeNull();
        }

        [Test, Category("Opdracht3")]
        public async Task CreativeTest_WeatherDescriptionIsNotEmpty()
        {
            var response = await _client.GetWeatherByCityAsync("Rotterdam", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            var weatherArray = json["weather"] as JArray;
            weatherArray.Should().NotBeNull();
            weatherArray.Count.Should().BeGreaterThan(0);
            weatherArray[0]?["description"].ToString().Should().NotBeNullOrEmpty();
        }

        [Test, Category("Opdracht3")]
        public async Task CreativeTest_WindInfoExists()
        {
            var response = await _client.GetWeatherByCityAsync("Den Haag", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            json["wind"].Should().NotBeNull();
            json["wind"]?["speed"].Should().NotBeNull();
        }

        [Test, Category("Opdracht3")]
        public async Task CreativeTest_CityCoordinatesExist()
        {
            var response = await _client.GetWeatherByCityAsync("Groningen", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            json["coord"]?["lat"].Should().NotBeNull();
            json["coord"]?["lon"].Should().NotBeNull();
        }

        [Test, Category("Opdracht3")]
        public async Task CreativeTest_TemperatureWithinReasonableRange()
        {
            var response = await _client.GetWeatherByCityAsync("Amsterdam", _appId);
            response.Status.Should().Be(200);

            var json = JObject.Parse(await response.TextAsync());
            var tempKelvin = json["main"]?["temp"]?.Value<double>() ?? double.NaN;

            // Converteer naar Celsius
            var tempCelsius = tempKelvin - 273.15;

            tempCelsius.Should().BeInRange(-50, 60); // realistisch temperatuurbereik op aarde
        }
    }
}
