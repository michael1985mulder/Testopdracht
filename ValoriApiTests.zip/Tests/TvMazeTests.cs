using Microsoft.Playwright.NUnit;
using NUnit.Framework;
using FluentAssertions;
using ValoriApiTests.Helpers;
using ValoriApiTests.ApiClients;
using Newtonsoft.Json.Linq;
using Microsoft.Playwright;
using System.Threading.Tasks;

namespace ValoriApiTests.Tests
{
    [TestFixture]
    public class TvMazeTests : PageTest
    {
        private IAPIRequestContext _api = null!;
        private TvMazeClient _client = null!;
        private string _baseUrl = null!;

        [OneTimeSetUp]
        public async Task OneTimeSetup()
        {
            var config = ApiHelper.LoadConfiguration();
            _baseUrl = config["TvMaze:BaseUrl"] ?? "https://api.tvmaze.com/";

            _api = await ApiHelper.CreateApiContextAsync("");
            _client = new TvMazeClient(_api, _baseUrl);
        }

        [OneTimeTearDown]
        public async Task OneTimeTeardown()
        {
            if (_api != null)
            {
                await _api.DisposeAsync();
            }
        }

        [Test]
        [Category("Opdracht5")]
        public async Task BreakingBad_ShouldContainIdInUrl()
        {
            var searchResponse = await _client.SearchShowAsync("breaking bad");
            searchResponse.Status.Should().Be(200);

            var jsonArray = JArray.Parse(await searchResponse.TextAsync());
            jsonArray.Count.Should().BeGreaterThan(0, "Expected at least one search result for 'breaking bad'");

            int showId = (int)jsonArray[0]["show"]["id"];

            var showResponse = await _client.GetShowByIdAsync(showId);
            showResponse.Status.Should().Be(200);

            var showJson = JObject.Parse(await showResponse.TextAsync());
            showJson["url"]!.ToString().Should().Contain(showId.ToString());
        }
    }
}
