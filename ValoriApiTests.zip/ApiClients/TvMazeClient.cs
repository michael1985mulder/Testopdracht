using System.Threading.Tasks;
using Microsoft.Playwright;
using ValoriApiTests.Utils;

namespace ValoriApiTests.ApiClients
{
    /// <summary>
    /// Deze klasse verzorgt communicatie met de publieke TV Maze API.
    /// De requests worden uitgevoerd via Playwright�s APIRequestContext (zonder browser).
    /// </summary>
    public class TvMazeClient
    {
        private readonly IAPIRequestContext _api;  // Playwright HTTP client voor API-aanroepen
        private readonly string _baseUrl;          // Basis-URL van de TV Maze API

        /// <summary>
        /// Constructor voor de TvMazeClient.
        /// </summary>
        /// <param name="api">De Playwright IAPIRequestContext die gebruikt wordt om HTTP requests uit te voeren.</param>
        /// <param name="baseUrl">De basis-URL van de TV Maze API (bijv. https://api.tvmaze.com/).</param>
        public TvMazeClient(IAPIRequestContext api, string baseUrl = "")
        {
            _api = api;
            _baseUrl = baseUrl;
        }

        /// <summary>
        /// Zoekt een tv-serie op basis van naam via het TV Maze "search/shows" endpoint.
        /// </summary>
        /// <param name="name">De naam van de serie die opgezocht moet worden (bijv. "Breaking Bad").</param>
        /// <returns>Een IAPIResponse met de JSON-array van zoekresultaten.</returns>
        public async Task<IAPIResponse> SearchShowAsync(string name)
        {
            // TV Maze vereist URL-encoded zoektermen (bijvoorbeeld "Breaking Bad" -> "Breaking%20Bad")
            var encoded = System.Net.WebUtility.UrlEncode(name);

            // Voer een GET-request uit naar het TV Maze zoekendpoint
            // Opmerking: TV Maze heeft zijn eigen API-basis, dus deze call gebruikt de baseUrl van TvMazeClient
            return await _api.GetAsync($"{_baseUrl}search/shows?q={encoded}");
        }

        /// <summary>
        /// Haalt details op van een specifieke serie aan de hand van het show ID.
        /// </summary>
        /// <param name="id">Het unieke show ID dat door TV Maze wordt gebruikt.</param>
        /// <returns>Een IAPIResponse met JSON-data over de specifieke show.</returns>
        public async Task<IAPIResponse> GetShowByIdAsync(int id)
        {
            // Stel de volledige URL samen voor het specifieke show endpoint
            var url = $"{_baseUrl}shows/{id}";

            // Log de URL van de request
            LoggerUtil.LogInfo($"[TvMazeClient] Sending GET request to: {url}");

            // Verstuur de GET request
            var response = await _api.GetAsync(url);

            // Log de HTTP-statuscode (bijv. 200 of 404)
            LoggerUtil.LogInfo($"[TvMazeClient] Response status: {response.Status}");

            // Log een korte preview van de response body
            var bodyPreview = (await response.TextAsync());
            if (bodyPreview.Length > 200)
                bodyPreview = bodyPreview.Substring(0, 200) + "...";

            LoggerUtil.LogInfo($"[TvMazeClient] Response body (preview): {bodyPreview}");

            // Retourneer de volledige response aan de aanroeper
            return response;
        }
    }
}
