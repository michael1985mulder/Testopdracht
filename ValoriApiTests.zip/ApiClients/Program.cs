﻿using Microsoft.Playwright;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        //await Playwright.InstallAsync();
        System.Console.WriteLine("Playwright browsers installed!");
    }
}
