using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Playwright;
using Newtonsoft.Json.Linq;
using ValoriApiTests.Utils;

namespace ValoriApiTests.ApiClients
{
    /// <summary>
    /// Deze klasse verzorgt communicatie met de OpenWeather API.
    /// De requests worden uitgevoerd via Playwright�s APIRequestContext (zonder browser).
    /// </summary>
    public class OpenWeatherClient
    {
        private readonly IAPIRequestContext _api;  // Playwright HTTP client voor API-aanroepen
        private readonly string _basePath;         // Basis-URL van de OpenWeather API

        /// <summary>
        /// Constructor voor de OpenWeatherClient.
        /// </summary>
        /// <param name="api">De Playwright IAPIRequestContext die gebruikt wordt voor HTTP-requests.</param>
        /// <param name="basePath">Optioneel: het basispad van de API (bijv. https://api.openweathermap.org/data/2.5/).</param>
        public OpenWeatherClient(IAPIRequestContext api, string basePath = "")
        {
            _api = api;
            _basePath = basePath;
        }

        /// <summary>
        /// Haalt het weer op voor een opgegeven stad via de OpenWeather API.
        /// </summary>
        /// <param name="city">De naam van de stad waarvoor het weer opgehaald moet worden.</param>
        /// <param name="appId">De API key (appid) voor authenticatie. Als deze null is, wordt het request anoniem uitgevoerd.</param>
        /// <returns>Een IAPIResponse object met de HTTP-response van de OpenWeather API.</returns>
        public async Task<IAPIResponse> GetWeatherByCityAsync(string city, string? appId = null)
        {
            // Stel de queryparameters samen die met de request meegestuurd worden
            var query = new Dictionary<string, string>
            {
                { "q", city }  // verplichte parameter: stad
            };

            // Voeg de API key toe aan de query als die is opgegeven
            if (!string.IsNullOrEmpty(appId))
                query.Add("appid", appId);

            // Log de request-informatie voor debug doeleinden
            LoggerUtil.LogInfo($"[OpenWeatherClient] Requesting weather for city: {city}");
            foreach (var kv in query)
            {
                LoggerUtil.LogInfo($"[OpenWeatherClient] Param: {kv.Key} = {kv.Value}");
            }

            // Playwright verwacht parameters als IEnumerable<KeyValuePair<string, object>>
            var queryObject = query.Select(kv => new KeyValuePair<string, object>(kv.Key, kv.Value));

            // Voer de GET request uit naar het /weather endpoint
            var response = await _api.GetAsync(_basePath + "weather", new APIRequestContextOptions
            {
                Params = queryObject
            });

            // Log de volledige response body als tekst
            var responseBody = await response.TextAsync();

            //parse JSON en log per key/value
            try
            {
                var json = JObject.Parse(responseBody);
                foreach (var prop in json.Properties())
                {
                    LoggerUtil.LogInfo($"[OpenWeatherClient] {prop.Name} = {prop.Value}");
                }
            }
            catch (Exception ex)
            {
                LoggerUtil.LogInfo($"[OpenWeatherClient] Response is geen valide JSON: {ex.Message}");
            }

            // Retourneer de volledige HTTP-response
            return response;
        }
    }
}
