﻿using Microsoft.Playwright;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;

namespace ValoriApiTests.Helpers
{
    public static class ApiHelper
    {
        /// <summary>
        /// Maakt een nieuwe APIRequestContext aan via Playwright.
        /// Dit object gebruik je om API-calls te doen (GET, POST, etc.) zonder een browser te openen.
        /// </summary>
        /// <param name="baseUrl">De basis-URL van de API (optioneel). Wordt automatisch toegevoegd aan alle requests.</param>
        /// <returns>Een IAPIRequestContext instantie waarmee je HTTP requests kunt uitvoeren.</returns>
        public static async Task<IAPIRequestContext> CreateApiContextAsync(string baseUrl = "")
        {
            // Start een nieuwe Playwright instantie (nodig om HTTP-context aan te maken)
            var playwright = await Playwright.CreateAsync();

            // Stel opties in voor de API context:
            var opts = new APIRequestNewContextOptions
            {
                BaseURL = baseUrl,
                IgnoreHTTPSErrors = true
            };

            // Maak een nieuwe API request context aan met de opgegeven instellingen
            return await playwright.APIRequest.NewContextAsync(opts);
        }

        /// <summary>
        /// Laadt configuratie-instellingen uit het bestand 'appsettings.json'.
        /// Dit bestand bevat meestal API keys, basis-URL’s, of andere testconfiguratie.
        /// </summary>
        /// <returns>Een IConfiguration object waarmee je waarden kunt uitlezen.</returns>
        public static IConfiguration LoadConfiguration()
        {
            // Maak een configuratiebuilder aan
            var builder = new ConfigurationBuilder()
                // Geef aan waar het bestand gezocht moet worden (huidige werkdirectory)
                .SetBasePath(Directory.GetCurrentDirectory())
                // Voeg het appsettings.json bestand toe
                // optional: false → bestand is verplicht, anders gooit het een fout
                // reloadOnChange: false → wijzigingen worden niet automatisch herladen
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: false);
            // Bouw en retourneer de configuratie
            return builder.Build();
        }
    }
}
