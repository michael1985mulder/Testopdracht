﻿using System;

namespace ValoriApiTests.Utils
{
    public static class LoggerUtil
    {
        private static readonly object _lock = new object();

        public static void LogInfo(string message)
        {
            lock (_lock)
            {
                var timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"[INFO] {timestamp} | {message}");
                Console.ResetColor();
            }
        }

        public static void LogError(string message, Exception? ex = null)
        {
            lock (_lock)
            {
                var timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[ERROR] {timestamp} | {message}");
                if (ex != null)
                {
                    Console.WriteLine($"[ERROR DETAILS] {ex}");
                }
                Console.ResetColor();
            }
        }
    }
}
