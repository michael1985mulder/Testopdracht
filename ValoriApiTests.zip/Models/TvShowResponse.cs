using Newtonsoft.Json;

namespace ValoriApiTests.Models
{
    public class TvShowResponse
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("url")]
        public string? Url { get; set; }
    }
}
